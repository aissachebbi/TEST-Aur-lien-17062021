package com.example.testaurelien.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.example.testaurelien")
public class TestAurelienConfig {

}
